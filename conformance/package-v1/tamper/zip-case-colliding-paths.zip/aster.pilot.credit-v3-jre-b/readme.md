lower-case twin of README.md
